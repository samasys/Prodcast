package com.primeforce.prodcast.businessobjects;

/**
 * Created by sarathan732 on 4/23/2016.
 */
public class Area {
    private long id;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    private String description;

}
