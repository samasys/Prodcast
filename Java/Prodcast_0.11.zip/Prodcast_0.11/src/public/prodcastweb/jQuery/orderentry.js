$(document).ready(function()
{
	
	var i;
	var area=["Area1","Area2", "Area3"];
	
	for(i=0;i<area.length;i++)
		{
	
	 	$('<option>'+area[i]+'</option>').appendTo('#selectarea');
		
		}
	
		
  
   
    
	
});







